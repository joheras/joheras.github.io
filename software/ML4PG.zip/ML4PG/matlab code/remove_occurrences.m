function s = remove_occurrences (x,array,len)
s = [];
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
else
  s = [s array(i)];
  i=i+1;
end
end
end