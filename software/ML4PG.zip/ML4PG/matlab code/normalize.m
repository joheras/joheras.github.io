function M1 = normalize (M)

[r,c] = size(M);
M1 = M;

for i=1:c
 mm = max(max(M(:,i)),abs(min(M(:,i))));
 if not(mm==0)   
  M1(:,i) =  M(:,i)./abs(mm);
 else 
   M1(:,i) =  M(:,i);
 end
end
end