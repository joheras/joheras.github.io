function temp1 = kmeans_clusters_and_frequencies (X,c,n,file)
% This function takes as arguments a dataset, Y, a number of clusters, c,
% and the number of times that you want to run an experiment, and computes
% the clusters over 0.5 and their frequencies.
[t1,X,t3] = princomp(X);
X = remove_null_columns(normalize(X));
temp=[];
j = 1;
while (j<=n)
    try
    [res,res1,res2] = kmeans(X,c,'distance','city');

    sil=silhouette(X,res,'city');
    i=1;
while(i<=c)
    if ((all_over(res,length(res),i,sil)) && (not_alone(res,length(res),i)))
      temp = [temp {extract_clusters(res,length(res),i)}]; 
    end
  i=i+1;
end
j=j+1;
    catch         
    end 
end

f=fopen(file,'w');

while (length(temp)>0)
y = temp(1);
 fprintf(f,'%s\n',y{1})
 fprintf(f,'[');
%disp([temp(1),(count_occurrences(temp(1),temp,length(temp))*100/n)]);   
 fprintf(f,'%i',(count_occurrences(temp(1),temp,length(temp))*100/n));  
 fprintf(f,']\n');
 temp=remove_occurrences(temp(1),temp,length(temp));
end

fclose(f);
end

function b = all_over (cl,n,c,sil)
b=1;
i=1;
while ((i<=n) && b)
    if ((cl(i)==c) && (0.5 > sil(i)))
      b = 0;
    end
    i=i+1;
end
end

function b = not_alone (cl,n,c)
b=-1;
i=1;
while (i<=n)
    if (cl(i)==c) 
      b = b + 1;
    end
    i=i+1;
end
end

function m = extract_clusters (cl,n,c)
i=1;
m='';
while (i<=n)
  if (cl(i)==c)
        m=strcat(m,num2str(i),',');
  end
  i=i+1;
end
m=remove_last(m);
end

function s = remove_occurrences (x,array,len)
s = [];
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
else
  s = [s array(i)];
  i=i+1;
end
end
end

function n = count_occurrences(x,array,len)
n=0;
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
   n=n+1;
else
  i=i+1;
end
end


end

function s = remove_last (str)
i=1;
s='';
while (i< length(str))
    s= strcat(s,str(i));
    i=i+1;
end
end

function M = remove_null_columns (M1)
[r,c] = size(M1);
c2=1;
for i=1:c
    if (not(all_zeros_p (M1(:,i))))
      M(:,c2) =  M1(:,i);
      c2=c2+1;  
    end
end
end

function b = all_zeros_p (c)
[r,c1] = size(c);
b=1;
i=1;
while (b && (i<=r))
  b = (c(i)==0);
  i=i+1;
end
end