function clusters_and_frequencies ( X,c,n)
% This function takes as arguments a dataset, X, a number of clusters, c,
% and the number of times that you want to run an experiment, and computes
% the clusters over 0.5 and their frequencies.
temp=[];
j = 1;
while (j<=n)
    res = kmeans(X,c,'distance','city');
    sil=silhouette(X,res,'city');
    i=1;
while(i<=c)
    if ((all_over(res,length(res),i,sil)) && (not_alone(res,length(res),i)))
      temp = [temp {extract_clusters(res,length(res),i)}]; 
    end
  i=i+1;
end
j=j+1;
end

while (length(temp)>0)
 disp([remove_last(temp(1)),(count_occurrences(temp(1),temp,length(temp))*100/n)]);     
 temp=remove_occurrences(temp(1),temp,length(temp));
end
end

function n = is_in_array(x,array)
n = 0;
i=1;
while ((i<= length(array)) && (n==0))
  if(strcmp(x,array(i)))
    n=i;   
  end
  i=i+1;
end
end

function b = all_over (cl,n,c,sil)
b=1;
i=1;
while ((i<=n) && b)
    if ((cl(i)==c) && (0.5 > sil(i)))
      b = 0;
    end
    i=i+1;
end
end

function b = not_alone (cl,n,c)
b=-1;
i=1;
while (i<=n)
    if (cl(i)==c) 
      b = b + 1;
    end
    i=i+1;
end
end

function m = extract_clusters (cl,n,c)
i=1;
m='';
while (i<=n)
  if (cl(i)==c)
        m=strcat(m,num2str(i),',');
  end
  i=i+1;
end
end

function s = remove_occurrences (x,array,len)
s = [];
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
else
  s = [s array(i)];
  i=i+1;
end
end
end

function n = count_occurrences(x,array,len)
n=0;
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
   n=n+1;
else
  i=i+1;
end
end


end

function s = remove_last (str)
i=1;
s='';
while (i< length(str))
    s= strcat(s,str(i));
    i=i+1;
end
end


