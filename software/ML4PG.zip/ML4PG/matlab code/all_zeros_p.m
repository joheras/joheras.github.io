function b = all_zeros_p (c)
[r,c1] = size(c);
b=1;
i=1;
while (b && (i<=r))
  b = not(c(i)==0);
  i=i+1;
end
end