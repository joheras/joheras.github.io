function m = extract_clusters (cl,n,c)
i=1;
m='';
while (i<=n)
  if (cl(i)==c)
        m=strcat(m,num2str(i),',');
  end
  i=i+1;
end
end