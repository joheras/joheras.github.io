function M = remove_null_columns (M1)
[r,c] = size(M1);
c2=1;
for i=1:c
    if (not(all_zeros_p (M1(:,i))))
      M(:,c2) =  M1(:,i);
      c2=c2+1;  
    end
end
end

function b = all_zeros_p (c)
[r,c1] = size(c);
b=1;
i=1;
while (b && (i<=r))
  b = (c(i)==0);
  i=i+1;
end
end