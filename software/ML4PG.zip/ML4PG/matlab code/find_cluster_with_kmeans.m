function temp1 = find_cluster_with_kmeans (X,c,n,file)
% This function takes as arguments a dataset, X, a number of clusters, c,
% and searchs in the clusters obtained if the element n of the dataset
% belongs to any of the clusters
 [t1,X,t3] = princomp(X);
 X = remove_null_columns(X);
 temp=[];
 j = 1;
 b=1;
 while ((j<=50) && b)
     try
     [res,res1,res2] = kmeans(X,c,'distance','city');
     sil=silhouette(X,res,'city');
     i=1;
 while ((i<=c) && b)
     if ((all_over(res,length(res),i,sil)) && (not_alone(res,length(res),i)))
         if (res(n)==i)
            b=0;
            temp = extract_clusters(res,length(res),i);
         end
     end
   i=i+1;
 end
 j=j+1;
     catch         
     end 
 end
 
 f=fopen(file,'w');
 
 if (length(temp)==0)
    fprintf(f,'None\n')
 else
     fprintf(f,'%s\n',temp)
 end 
 
 fclose(f);
     
 end

function b = all_over (cl,n,c,sil)
b=1;
i=1;
while ((i<=n) && b)
    if ((cl(i)==c) && (0.5 > sil(i)))
      b = 0;
    end
    i=i+1;
end
end

function b = not_alone (cl,n,c)
b=-1;
i=1;
while (i<=n)
    if (cl(i)==c) 
      b = b + 1;
    end
    i=i+1;
end
end

function m = extract_clusters (cl,n,c)
i=1;
m='';
while (i<=n)
  if (cl(i)==c)
        m=strcat(m,num2str(i),',');
  end
  i=i+1;
end
m=remove_last(m);
end

function s = remove_occurrences (x,array,len)
s = [];
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
else
  s = [s array(i)];
  i=i+1;
end
end
end

function n = count_occurrences(x,array,len)
n=0;
i=1;
while(i<=len)
if (strcmp(x,array(i)))
   i=i+1;
   n=n+1;
else
  i=i+1;
end
end


end

function s = remove_last (str)
i=1;
s='';
while (i< length(str))
    s= strcat(s,str(i));
    i=i+1;
end
end

function M = remove_null_columns (M1)
[r,c] = size(M1);
c2=1;
for i=1:c
    if (not(all_zeros_p (M1(:,i))))
      M(:,c2) =  M1(:,i);
      c2=c2+1;  
    end
end
end

function b = all_zeros_p (c)
[r,c1] = size(c);
b=1;
i=1;
while (b && (i<=r))
  b = (c(i)==0);
  i=i+1;
end
end
