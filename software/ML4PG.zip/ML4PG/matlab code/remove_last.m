function s = remove_last (str)
i=1;
s='';
while (i< length(str))
    s= strcat(s,str(i));
    i=i+1;
end
end